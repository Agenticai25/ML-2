import streamlit as st
import pandas as pd
import json
import requests
from io import BytesIO

# --- Page Config ---
st.set_page_config(
    page_title="Cosmic case SLA prediction",
    page_icon="🏢",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- Custom CSS for Microsoft/Azure Look ---
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Segoe+UI&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Segoe UI', sans-serif;
        background-color: #faf9f8;
        color: #201f1e;
    }
    
    /* Sidebar styling */
    section[data-testid="stSidebar"] {
        background-color: #ffffff;
        border-right: 1px solid #e1dfdd;
    }
    
    /* Header styling */
    h1 {
        font-family: 'Segoe UI', sans-serif;
        font-weight: 600;
        color: #201f1e;
        font-size: 1.5rem;
    }
    
    /* Button styling */
    .stButton > button {
        background-color: #ffffff;
        color: #323130;
        border: 1px solid #8a8886;
        border-radius: 2px;
        font-size: 14px;
    }
    .stButton > button:hover {
        background-color: #f3f2f1;
        border-color: #8a8886;
        color: #201f1e;
    }
    
    /* Primary Button styling (mocking specific button) */
    div[data-testid="stHorizontalBlock"] button[kind="primary"] {
        background-color: #0078d4;
        color: white;
        border: none;
    }
    
    /* Tabs styling */
    .stTabs [data-baseweb="tab-list"] {
        gap: 20px;
        border-bottom: 1px solid #e1dfdd;
    }
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        white-space: pre-wrap;
        background-color: transparent;
        border-radius: 0px;
        color: #a19f9d;
        font-size: 14px;
    }
    .stTabs [aria-selected="true"] {
        color: #0078d4 !important;
        border-bottom: 2px solid #0078d4;
    }
    
    /* Dataframe styling */
    .stDataFrame {
        border: 1px solid #e1dfdd;
        background-color: white;
    }
    
    /* Input fields */
    input {
        background-color: #f3f2f1;
        border: 1px solid transparent;
    }
    
    /* Success/Error boxes */
    .stSuccess, .stError {
        border-radius: 2px;
    }

    .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
    }
</style>
""", unsafe_allow_html=True)

# --- Sidebar ---
with st.sidebar:
    st.markdown("### Connection")
    st.markdown("<p style='font-size: 12px; color: #605e5c;'>Defaulting to the cloud Function App endpoints:</p>", unsafe_allow_html=True)
    
    st.text_input("train", value="https://func-sla-lightgbm-train-uat...", disabled=True)
    st.text_input("infer", value="https://func-sla-catboost-infer-uat-eastus.azurewebsites.net/predict", disabled=True)
    
    st.checkbox("Override endpoints", help="Enable to edit endpoints")
    
    st.text_input("Function key (optional)", type="password", help="Enter function key if required")
    
    st.markdown("---")
    st.markdown("### Request options")
    st.selectbox("timeoutSeconds", options=[3600], index=0)

# --- Main Content ---

# Header
col1, col2 = st.columns([0.05, 0.95])
with col1:
    try:
        st.image("streamlit_app/assets/microsoft-logo.png", width=100)
    except:
        st.write("Microsoft") # Fallback
with col2:
    st.markdown("# Cosmic case SLA prediction with CatBoost")

st.markdown("<p style='margin-left: 0px; color: #605e5c; font-size: 14px; margin-bottom: 20px;'>Train a model, review metrics, then run inference and view readable results.</p>", unsafe_allow_html=True)

# Tabs
tab_train, tab_infer = st.tabs(["Train", "Infer"])

with tab_train:
    st.info("Training module is disabled in this view.")

with tab_infer:
    # 1. Inference Input Section
    st.markdown("### Inference input")
    
    uploaded_file = st.file_uploader("Upload inference CSV/Excel (optional)", type=["csv", "xlsx", "xls"])
    
    if "data" not in st.session_state:
        st.session_state.data = None
    if "selected_index" not in st.session_state:
        st.session_state.selected_index = 0
    if "inference_result" not in st.session_state:
        st.session_state.inference_result = None
    if "built_payload" not in st.session_state:
        st.session_state.built_payload = None

    if uploaded_file:
        try:
            if uploaded_file.name.endswith('.csv'):
                df = pd.read_csv(uploaded_file)
            else:
                df = pd.read_excel(uploaded_file)
            
            st.session_state.data = df
            
            # Show Dataframe
            with st.expander("Preview uploaded file", expanded=True):
                st.dataframe(df, use_container_width=True, height=300)
                st.checkbox("Use uploaded file for inference (score ALL rows)")
                
        except Exception as e:
            st.error(f"Error reading file: {e}")

    # 2. Build Payload Section
    if st.session_state.data is not None:
        df = st.session_state.data
        total_rows = len(df)
        
        # Result Display (Top)
        if st.session_state.inference_result:
            st.success("Inference output:")
            st.code(json.dumps(st.session_state.inference_result, indent=2), language="json")

        st.markdown("---")
        st.markdown(f"### Build payload from a specific row (and save to `payloads/`)")
        st.markdown("<p style='font-size: 12px; color: #605e5c;'>Pick a row number and construct a single-row payload. Resolved-time columns are dropped.</p>", unsafe_allow_html=True)
        
        col_row_input, col_file_input = st.columns([1, 2])
        
        with col_row_input:
            row_num = st.number_input(
                "Row number (1-based)", 
                min_value=1, 
                max_value=total_rows, 
                value=st.session_state.selected_index + 1,
                step=1
            )
            # Update selected index based on input
            if row_num - 1 != st.session_state.selected_index:
                 st.session_state.selected_index = row_num - 1
                 st.session_state.built_payload = None # Reset payload on change
        
        with col_file_input:
            st.text_input("Payload file to update (repo-relative)", value="payloads/infer_inline.json", disabled=True)
            
        # Action Buttons
        col_btn1, col_btn2, col_btn3, col_spacer = st.columns([1, 1, 1, 3])
        with col_btn1:
            if st.button("Build payload from row"):
                row_data = df.iloc[st.session_state.selected_index].to_dict()
                # Handle non-serializable types (like timestamps)
                row_data_cleaned = json.loads(pd.Series(row_data).to_json(date_format='iso'))
                st.session_state.built_payload = json.dumps(row_data_cleaned, indent=2)
                
        with col_btn2:
            st.button("Save payload JSON to file")
        with col_btn3:
            st.button("Build + Save")
            
        # 3. Infer Request Body Section
        st.markdown("### Infer request body")
        st.markdown("<p style='font-size: 12px; color: #605e5c;'>Recommended: build a single-row payload above. Advanced: edit raw JSON below.</p>", unsafe_allow_html=True)
        
        with st.expander("Advanced: edit infer request JSON", expanded=False):
            payload_text = st.text_area(
                "Request JSON", 
                value=st.session_state.built_payload if st.session_state.built_payload else "// Click 'Build payload from row' to generate",
                height=200
            )
            if payload_text and payload_text.startswith("{"):
                 st.session_state.built_payload = payload_text

        if st.button("Run inference", type="primary", disabled=not st.session_state.built_payload):
            if st.session_state.built_payload:
                try:
                    payload_json = json.loads(st.session_state.built_payload)
                    
                    with st.spinner("Running inference..."):
                        # Attempt to call actual API
                        api_url = "https://func-sla-catboost-infer-uat-eastus.azurewebsites.net/predict"
                        try:
                            # In Replit or local dev, CORS isn't usually an issue for Python requests unlike browser fetch
                            response = requests.post(api_url, json=payload_json, headers={"Content-Type": "application/json"})
                            
                            if response.status_code == 200:
                                st.session_state.inference_result = response.json()
                            else:
                                # If API fails, show error but also mock for demo if requested
                                st.error(f"API Error: {response.status_code} - {response.text}")
                                # Mock fallback for demo continuity
                                st.session_state.inference_result = {
                                    "status": "error",
                                    "message": "Real API call failed, but here is the mock structure",
                                    "prediction": 0.85
                                }
                        except Exception as req_err:
                            st.error(f"Connection Error: {req_err}")
                            # Mock fallback
                            st.session_state.inference_result = {
                                "prediction": 0.8234,
                                "status": "success (MOCK)",
                                "explanation": "Generated because live endpoint is unreachable."
                            }
                            
                except json.JSONDecodeError:
                    st.error("Invalid JSON payload")

        st.caption("Calling: https://func-sla-catboost-infer-uat-eastus.azurewebsites.net/predict")

    else:
        st.info("Please upload a file to begin.")
