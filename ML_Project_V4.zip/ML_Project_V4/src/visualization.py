import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import seaborn as sns
import re
import math
from textwrap import fill


def save_eda_plots(df, X, y, categorical_cols, plot_folder):
    """Contains all EDA plotting logic from the original script."""

    # A. Target Distribution with Descriptive Statistics Box
    plt.figure(figsize=(12, 6))

    # Calculate descriptive statistics for target_minutes
    stats = pd.Series(y).describe()
    stats_str = "--- Statistics ---\n" + "\n".join([f"{idx:<8}: {val:>10.2f}" for idx, val in stats.items()])

    # Plotting Histogram
    ax = sns.histplot(y, bins=40, kde=True, color='purple')
    plt.title("Distribution of Y Feature (target_minutes)")
    plt.xlabel("Y Value (Minutes)")
    plt.ylabel("Frequency")
    plt.grid(True, alpha=0.3)

    # Add the "Describe" box to the right side of the plot
    plt.annotate(
        stats_str,
        xy=(1.02, 0.5),
        xycoords='axes fraction',
        fontsize=10,
        family='monospace',  # Monospace ensures numbers align vertically
        bbox=dict(boxstyle="round,pad=0.5", fc="white", ec="purple", lw=1.5),
        verticalalignment='center'
    )
    # Adjust layout to make room for the annotation box
    plt.tight_layout(rect=[0, 0, 0.82, 1])
    plt.savefig(os.path.join(plot_folder, 'target_distribution_y.png'))
    plt.close()

    # # A. Target Distribution
    # plt.figure(figsize=(10, 5))
    # sns.histplot(y, bins=40, kde=True, color='purple')
    # plt.title("Distribution of Y Feature (target_minutes)")
    # plt.xlabel("Y Value")
    # plt.ylabel("Frequency")
    # plt.grid(True, alpha=0.3)
    # plt.tight_layout()
    # plt.savefig(os.path.join(plot_folder, 'target_distribution_y.png'))
    # plt.close()

    # B. Unique Category Counts
    unique_counts = (
        pd.Series({col: df[col].nunique(dropna=True) for col in categorical_cols})
        .sort_values(ascending=False)
    )
    plt.figure(figsize=(12, 6))
    sns.barplot(x=unique_counts.values, y=unique_counts.index, palette='viridis')
    plt.title("Number of Categories vs Unique Category Count")
    for index, value in enumerate(unique_counts.values):
        plt.text(value + max(unique_counts.values) * 0.02, index, str(value), va='center')
    plt.tight_layout()
    plt.savefig(os.path.join(plot_folder, 'categorical_unique_counts.png'), dpi=300)
    plt.close()

    # C. Distribution for all columns
    cols_to_exclude = ['received_dt', 'resolved_dt', 'msdyn_receiveddate', 'msdyn_resolveddate']
    all_cols = [col for col in df.columns if col not in cols_to_exclude]
    for col in all_cols:
        plt.figure(figsize=(16, 8))
        if pd.api.types.is_numeric_dtype(df[col]):
            sns.histplot(df[col], bins=30, kde=True, color='teal')
        else:
            order = df[col].value_counts().head(20).index
            plot_data = df[df[col].isin(order)]
            sns.countplot(data=plot_data, y=col, order=order, palette='viridis')
        plt.title(f'Distribution: {col}')
        clean_name = re.sub(r'[^a-zA-Z0-9]', '_', str(col))
        plt.savefig(os.path.join(plot_folder, f'dist_{clean_name}.png'))
        plt.close()


def plot_training_results(final_model, top_features, y_test_actual, preds_actual, plot_folder):
    """Plots importance and residuals after training."""

    # Feature Importance
    imps = final_model.get_feature_importance()
    labels = [fill(lbl, width=22) for lbl in top_features]
    plt.figure(figsize=(12, 8))
    sns.barplot(x=imps, y=labels, palette='coolwarm')
    plt.title('Final Feature Importance: Optimized Model')
    plt.tight_layout()
    plt.savefig(os.path.join(plot_folder, 'optimized_feature_importance.png'), dpi=200)
    plt.close()

    # Error Residuals
    plt.figure(figsize=(10, 6))
    residuals = y_test_actual - preds_actual
    sns.histplot(residuals, kde=True, bins=50, color='crimson')
    plt.title('Error Residuals (Actual - Predicted)')
    plt.xlabel('Minutes Deviation')
    plt.savefig(os.path.join(plot_folder, 'error_residuals.png'))
    plt.close()


def plot_demo_performance(demo_df, plot_folder):
    """The final Actual vs Predicted scatter plot."""
    plt.figure(figsize=(12, 7))
    demo_df['abs_error'] = (demo_df['target_minutes'] - demo_df['predicted_resolution_minutes']).abs()
    sns.scatterplot(
        x='target_minutes', y='predicted_resolution_minutes',
        hue='abs_error', palette='viridis', data=demo_df, alpha=0.8
    )
    max_val = max(demo_df['target_minutes'].max(), demo_df['predicted_resolution_minutes'].max())
    plt.plot([0, max_val], [0, max_val], color='red', linestyle='--')
    plt.title('Demo Data: Actual vs. Predicted')
    plt.savefig(os.path.join(plot_folder, 'demo_actual_vs_pred_colored.png'))
    plt.close()

