import pandas as pd
import numpy as np
import os

def adjust_for_weekend(dt):
    """Adjusts a datetime if it falls on a Saturday or Sunday."""
    if dt.weekday() == 5:  # Saturday
        return dt + pd.Timedelta(days=2)
    elif dt.weekday() == 6:  # Sunday
        return dt + pd.Timedelta(days=1)
    return dt

def generate_demo_predictions(model, demo_df, top_features, final_cat_features, median_speed_map, global_median):
    """Processes demo data and returns predictions with weekend adjustments."""

    # Feature Engineering for Demo
    demo_df['received_dt'] = pd.to_datetime(demo_df['msdyn_receiveddate'], errors='coerce')
    demo_df['hour_of_day'] = demo_df['received_dt'].dt.hour.astype(str)
    demo_df['day_of_week'] = demo_df['received_dt'].dt.dayofweek.astype(str)
    demo_df['daily_volume'] = demo_df.groupby(demo_df['received_dt'].dt.date)['msdyn_caserocname'].transform('count')

    # Target Encoding using map from training
    demo_df['reason_median_speed'] = demo_df['msdyn_casereasonidname'].map(median_speed_map).fillna(global_median)

    # Categorical Cleaning
    for col in final_cat_features:
        demo_df[col] = (
            demo_df[col]
            .map(lambda x: str(int(x)) if pd.notnull(x) and isinstance(x, (float, int)) else str(x))
            .replace('nan', 'Unknown')
        )

    # Predict
    X_demo = demo_df[top_features]
    preds_log = model.predict(X_demo)
    demo_df['predicted_resolution_minutes'] = np.expm1(preds_log)

    # Error Calculation
    demo_df['prediction_error'] = (demo_df['target_minutes'] - demo_df['predicted_resolution_minutes']).abs()

    # Time Calculation & Weekend Adjustment
    demo_df['msdyn_receiveddate'] = pd.to_datetime(demo_df['msdyn_receiveddate'])
    raw_finish = demo_df['msdyn_receiveddate'] + pd.to_timedelta(demo_df['predicted_resolution_minutes'], unit='m')
    demo_df['predicted_resolved_date'] = raw_finish.apply(adjust_for_weekend)

    # Reorder Columns (Target and Prediction at the front)
    cols = [col for col in demo_df.columns if col not in ['target_minutes', 'predicted_resolution_minutes']]
    ordered_df = demo_df[['target_minutes', 'predicted_resolution_minutes'] + cols]

    return ordered_df

